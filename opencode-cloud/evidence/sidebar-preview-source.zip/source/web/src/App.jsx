import { useState, useRef, useEffect } from 'react';

export default function App() {
  const [files, setFiles] = useState([]);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .app { max-width: 720px; margin: 0 auto; }
      .header { text-align: center; margin-bottom: 2rem; }
      .header h1 { font-size: 2rem; color: #f1f5f9; margin-bottom: 0.5rem; }
      .subtitle { color: #94a3b8; font-size: 0.95rem; }
      .drop-zone {
        border: 2px dashed #475569; border-radius: 16px; padding: 3rem 2rem;
        text-align: center; cursor: pointer; transition: all 0.2s;
        background: rgba(255,255,255,0.03);
      }
      .drop-zone:hover, .drop-zone.drag-over {
        border-color: #818cf8; background: rgba(129,140,248,0.08);
        transform: scale(1.01);
      }
      .drop-zone-icon { font-size: 3rem; margin-bottom: 1rem; }
      .drop-zone-text { font-size: 1.1rem; color: #cbd5e1; margin-bottom: 0.5rem; }
      .drop-zone-hint { font-size: 0.85rem; color: #64748b; }
      .file-section { margin-top: 1.5rem; }
      .file-header {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 1rem; padding: 0 0.25rem;
      }
      .file-header span { font-weight: 600; font-size: 1.05rem; }
      .file-actions { display: flex; gap: 0.5rem; }
      .btn {
        padding: 0.45rem 1rem; border: none; border-radius: 8px; cursor: pointer;
        font-size: 0.9rem; font-weight: 500; transition: all 0.15s;
      }
      .btn:disabled { opacity: 0.5; cursor: not-allowed; }
      .btn-primary { background: #818cf8; color: #fff; }
      .btn-primary:hover:not(:disabled) { background: #6366f1; }
      .btn-secondary { background: #334155; color: #e2e8f0; }
      .btn-secondary:hover { background: #475569; }
      .btn-download { background: #22c55e; color: #fff; font-size: 1.1rem; padding: 0.4rem 0.7rem; }
      .btn-download:hover { background: #16a34a; }
      .btn-upload { background: #3b82f6; color: #fff; font-size: 1.1rem; padding: 0.4rem 0.7rem; }
      .btn-upload:hover { background: #2563eb; }
      .btn-delete { background: #ef4444; color: #fff; font-size: 1.1rem; padding: 0.4rem 0.7rem; }
      .btn-delete:hover { background: #dc2626; }
      .file-list { display: flex; flex-direction: column; gap: 0.6rem; }
      .file-card {
        display: flex; align-items: center; gap: 1rem; padding: 0.85rem 1rem;
        background: rgba(255,255,255,0.05); border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.06); transition: all 0.15s;
      }
      .file-card:hover { background: rgba(255,255,255,0.08); }
      .file-icon { font-size: 1.8rem; flex-shrink: 0; }
      .file-info { flex: 1; min-width: 0; }
      .file-name { font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 0.25rem; }
      .file-meta { display: flex; gap: 1rem; font-size: 0.8rem; color: #94a3b8; }
      .file-status { font-weight: 500; }
      .progress-bar {
        height: 4px; background: #334155; border-radius: 2px; margin-top: 0.4rem; overflow: hidden;
      }
      .progress-fill { height: 100%; background: linear-gradient(90deg, #818cf8, #6366f1); border-radius: 2px; transition: width 0.3s; }
      .empty-state { text-align: center; margin-top: 3rem; color: #475569; font-size: 1rem; }
    `;
    document.head.appendChild(style);
    return () => { document.head.removeChild(style); };
  }, []);

  const formatSize = (bytes) => {
    if (bytes === 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 2) + ' ' + units[i];
  };

  const addFiles = (newFiles) => {
    const fileArray = Array.from(newFiles);
    const withMeta = fileArray.map((f) => ({
      id: Date.now() + Math.random(),
      name: f.name,
      size: f.size,
      type: f.type || 'unknown',
      lastModified: f.lastModified,
      file: f,
      status: 'ready',
      progress: 100,
    }));
    setFiles((prev) => [...withMeta, ...prev]);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => setDragging(false);

  const handleFilePicker = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = (e) => {
    if (e.target.files.length) addFiles(e.target.files);
    e.target.value = '';
  };

  const handleUpload = (id) => {
    const f = files.find((x) => x.id === id);
    if (!f) return;
    f.status = 'uploading';
    setFiles((prev) => prev.map((x) => (x.id === id ? { ...x, status: 'uploading', progress: 0 } : x)));

    // Simulate upload progress
    let p = 0;
    const timer = setInterval(() => {
      p += Math.random() * 30 + 10;
      if (p >= 100) {
        p = 100;
        clearInterval(timer);
        setFiles((prev) =>
          prev.map((x) => (x.id === id ? { ...x, status: 'uploaded', progress: 100 } : x))
        );
      } else {
        setFiles((prev) =>
          prev.map((x) => (x.id === id ? { ...x, progress: Math.round(p) } : x))
        );
      }
    }, 300);
  };

  const handleUploadAll = () => {
    setUploading(true);
    const readyFiles = files.filter((f) => f.status === 'ready');
    if (readyFiles.length === 0) {
      setUploading(false);
      return;
    }
    readyFiles.forEach((f) => handleUpload(f.id));
  };

  const handleDownload = (f) => {
    const url = URL.createObjectURL(f.file);
    const a = document.createElement('a');
    a.href = url;
    a.download = f.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDelete = (id) => {
    setFiles((prev) => prev.filter((x) => x.id !== id));
  };

  const handleClearAll = () => {
    setFiles([]);
    setUploading(false);
  };

  const statusText = (status) => {
    if (status === 'uploading') return '上传中...';
    if (status === 'uploaded') return '已上传';
    return '就绪';
  };

  const statusColor = (status) => {
    if (status === 'uploading') return '#f59e0b';
    if (status === 'uploaded') return '#22c55e';
    return '#6366f1';
  };

  return (
    <div className="app">
      <header className="header">
        <h1>📁 文件上传下载</h1>
        <p className="subtitle">拖拽文件到下方区域，或点击选择文件</p>
        <p className="subtitle" style={{ fontSize: '0.8rem', marginTop: '0.25rem', color: '#6366f1' }}>WorkBench：热更新状态已保留</p>
      </header>

      <div
        className={`drop-zone ${dragging ? 'drag-over' : ''}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={handleFilePicker}
      >
        <div className="drop-zone-icon">📂</div>
        <p className="drop-zone-text">
          {dragging ? '松开上传文件' : '拖拽文件到此处 或 点击选择'}
        </p>
        <p className="drop-zone-hint">支持多文件同时上传</p>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          hidden
          onChange={handleFileSelect}
        />
      </div>

      {files.length > 0 && (
        <div className="file-section">
          <div className="file-header">
            <span>文件列表 ({files.length})</span>
            <div className="file-actions">
              {files.some((f) => f.status === 'ready') && (
                <button className="btn btn-primary" onClick={handleUploadAll} disabled={uploading}>
                  {uploading ? '上传中...' : '⬆ 全部上传'}
                </button>
              )}
              {files.some((f) => f.status === 'uploaded') && (
                <button className="btn btn-secondary" onClick={handleClearAll}>
                  🗑 清空列表
                </button>
              )}
            </div>
          </div>

          <div className="file-list">
            {files.map((f) => (
              <div key={f.id} className="file-card">
                <div className="file-icon">
                  {f.type.startsWith('image/') ? '🖼' : f.type.startsWith('video/') ? '🎬' : f.type.startsWith('audio/') ? '🎵' : f.type.includes('pdf') ? '📄' : f.type.includes('zip') || f.type.includes('tar') || f.type.includes('rar') ? '📦' : '📎'}
                </div>
                <div className="file-info">
                  <div className="file-name" title={f.name}>{f.name}</div>
                  <div className="file-meta">
                    <span>{formatSize(f.size)}</span>
                    <span className="file-status" style={{ color: statusColor(f.status) }}>
                      {statusText(f.status)}
                    </span>
                  </div>
                  {f.status === 'uploading' && (
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: f.progress + '%' }}></div>
                    </div>
                  )}
                </div>
                <div className="file-actions">
                  {f.status === 'uploaded' && (
                    <button className="btn btn-download" onClick={() => handleDownload(f)} title="下载">
                      ⬇
                    </button>
                  )}
                  {f.status === 'ready' && (
                    <button className="btn btn-upload" onClick={() => handleUpload(f.id)} title="上传">
                      ⬆
                    </button>
                  )}
                  <button className="btn btn-delete" onClick={() => handleDelete(f.id)} title="删除">
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {files.length === 0 && (
        <div className="empty-state">
          <p>暂无文件，请添加文件开始</p>
        </div>
      )}
    </div>
  );
}
