# WorkBench source export

The complete deliverable source is in source/. No baseline checkout is needed.

For a Vite/React project: cd source/web; npm ci --maxsockets=2 --fetch-retries=0; npm test; npm run build; npm run dev -- --host 127.0.0.1 --port 5173 --strictPort.
For plain HTML/CSS/JS: cd source/web; npx --yes vite@7.3.6 --host 127.0.0.1 --port 5173 --strictPort (downloads this fixed version if unavailable).
Read the project README for its actual tests. An export is not proof that builds or tests passed.
Dependencies, credentials, browser state and verification artifacts are excluded; obtain dependencies from the lockfile.
