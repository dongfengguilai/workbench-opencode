import { test } from 'node:test';
import assert from 'node:assert/strict';
import { countCharacters, countWords } from './stats.mjs';

test('中文字符数', () => {
	assert.equal(countCharacters('你好世界'), 4);
});

test('中文词数', () => {
	assert.equal(countWords('你好 世界'), 2);
});

test('非BMP emoji 字符数', () => {
	assert.equal(countCharacters('\uD83D\uDE00'), 1);
});

test('非BMP emoji 词数', () => {
	assert.equal(countWords('😀🎉'), 1);
});

test('混合字符数', () => {
	assert.equal(countCharacters('a😀b'), 3);
});

test('Tab 和换行分隔词数', () => {
	assert.equal(countWords('hello\tworld\nfoo'), 3);
});

test('Tab 和换行计字符', () => {
	assert.equal(countCharacters('a\t\nb'), 4);
});

test('纯空白词数', () => {
	assert.equal(countWords('   \n\t  '), 0);
});

test('空字符串词数', () => {
	assert.equal(countWords(''), 0);
});

test('普通多词词数', () => {
	assert.equal(countWords('Hello world foo bar'), 4);
});

test('普通多词字符数', () => {
	assert.equal(countCharacters('Hello world'), 11);
});

test('单字词数', () => {
	assert.equal(countWords('one'), 1);
});

test('混合中文 emoji 空白 字符数', () => {
	assert.equal(countCharacters('你好 😀\n世界\t!'), 9);
});

test('混合中文 emoji 空白 词数', () => {
	assert.equal(countWords('你好 😀\n世界\t!'), 4);
});
