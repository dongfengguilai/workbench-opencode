import { useState } from 'react';
import { countCharacters, countWords } from '../stats.mjs';

export default function App() {
  const [text, setText] = useState('');
  const [charCount, setCharCount] = useState(0);
  const [wordCount, setWordCount] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleStat = () => {
    setCharCount(countCharacters(text));
    setWordCount(countWords(text));
    setShowResult(true);
  };

  const handleClear = () => {
    setText('');
    setCharCount(0);
    setWordCount(0);
    setShowResult(false);
  };

  const handleExample = () => {
    setText('你好 😀\n世界\t!');
    setShowResult(false);
  };

  return (
    <div className="container">
      <h1>文本统计器 · React</h1>
      <label htmlFor="inputText">输入文本</label>
      <textarea
        id="inputText"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="在此输入或粘贴文本..."
        rows={8}
      />
      <div className="btn-row">
        <button onClick={handleStat}>统 计</button>
        <button onClick={handleClear}>清 空</button>
      </div>
      <button className="example-btn" onClick={handleExample}>示例文本</button>
      {showResult && (
        <div className="result">
          <p>字符数：<span className="num">{charCount}</span></p>
          <p>单词数：<span className="num">{wordCount}</span></p>
        </div>
      )}
    </div>
  );
}
