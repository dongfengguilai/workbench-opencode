export function normalizeWhitespace(input) {
  if (typeof input !== 'string') {
    throw new TypeError('input must be a string');
  }

  return input.trim().replace(/\s+/gu, ' ');
}
