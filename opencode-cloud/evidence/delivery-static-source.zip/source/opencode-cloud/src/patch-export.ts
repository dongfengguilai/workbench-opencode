import { execFileSync } from 'node:child_process';
import { lstat, mkdtemp, realpath, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

type ExportOptions = { directory: string; baseline: string };
type ExportResult = { baseline: string; files: string[]; patch: string };

function git(directory: string, args: string[], env?: NodeJS.ProcessEnv): Buffer {
  return execFileSync('git', args, { cwd: directory, env, maxBuffer: 128 * 1024 * 1024 });
}

function nulList(value: Buffer): string[] {
  return value.toString('utf8').split('\0').filter(Boolean);
}

function isExcluded(file: string): boolean {
  const parts = file.split('/');
  const lower = file.toLowerCase();
  const base = parts.at(-1)!.toLowerCase();
  if (base === '.env' || base.startsWith('.env.')) return true;
  if (/\.(pem|key|p12|pfx|jks|kdb|crt)$/i.test(base)) return true;
  if (/(^|[/._-])(credential|credentials|key|keys|secret|secrets)([/._-]|$)/i.test(lower)) return true;

  const excludedDirectories = new Set([
    '.cache', '.gradle', '.m2', '.npm', '.pnpm-store', '.venv',
    'cache', 'caches', 'db', 'database', 'databases', 'deps', 'dependencies',
    'node_modules', 'runtime', 'state', 'tmp', 'vendor', 'venv',
  ]);
  return parts.slice(0, -1).some(part => excludedDirectories.has(part.toLowerCase()));
}

async function rejectUnsafeSymlinks(directory: string, files: string[]): Promise<void> {
  const root = await realpath(directory);
  for (const file of files) {
    const fullPath = path.join(directory, ...file.split('/'));
    let stat;
    try { stat = await lstat(fullPath); } catch (error: any) {
      if (error?.code === 'ENOENT') continue;
      throw error;
    }
    if (!stat.isSymbolicLink()) continue;
    let target: string;
    try { target = await realpath(fullPath); } catch { throw new Error(`External or broken symlink: ${file}`); }
    const relative = path.relative(root, target);
    if (relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) {
      throw new Error(`External or broken symlink: ${file}`);
    }
  }
}

export async function exportPatch({ directory, baseline }: ExportOptions): Promise<ExportResult> {
  const expected = git(directory, ['rev-parse', '--verify', 'HEAD']).toString().trim();
  if (!/^[0-9a-f]{40}$/.test(baseline) || baseline !== expected) {
    throw new Error('baseline must be the full SHA matching HEAD');
  }

  const candidateFiles = nulList(git(directory, ['ls-files', '--cached', '--others', '--exclude-standard', '-z', '--']));
  await rejectUnsafeSymlinks(directory, candidateFiles);

  const tempDirectory = await mkdtemp(path.join(os.tmpdir(), 'opencode-cloud-index-'));
  const index = path.join(tempDirectory, 'index');
  const env = { ...process.env, GIT_INDEX_FILE: index };
  try {
    git(directory, ['read-tree', baseline], env);
    git(directory, ['add', '--all', '--', '.'], env);

    const baselineFiles = nulList(git(directory, ['ls-tree', '-r', '--name-only', '-z', baseline, '--']));
    const excluded = baselineFiles.filter(isExcluded);
    const excludedCandidates = candidateFiles.filter(isExcluded);
    for (const file of excluded) {
      const entry = git(directory, ['ls-tree', '-z', baseline, '--', file]).toString('utf8').replace(/\0$/, '');
      const match = entry.match(/^(\d+) blob ([0-9a-f]+)\t/);
      if (!match) throw new Error(`Unable to restore excluded path: ${file}`);
      git(directory, ['update-index', '--add', '--cacheinfo', `${match[1]},${match[2]},${file}`], env);
    }
    for (const file of excludedCandidates) {
      if (!excluded.includes(file)) git(directory, ['update-index', '--force-remove', '--', file], env);
    }

    const files = nulList(git(directory, ['diff', '--cached', '--name-only', '-z', '--'], env));
    const patch = git(directory, ['diff', '--cached', '--binary', '--full-index', '--no-ext-diff', '--'], env).toString('utf8');
    return { baseline, files, patch };
  } finally {
    await rm(tempDirectory, { recursive: true, force: true });
  }
}
