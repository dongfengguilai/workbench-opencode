export function initials(input) {
  if (typeof input !== 'string') {
    throw new TypeError('Expected a string');
  }
  const trimmed = input.trim();
  if (trimmed === '') {
    return '';
  }
  const words = trimmed.split(/\s+/);
  const first = [...words[0]][0];
  const second = words[1] ? [...words[1]][0] : '';
  return (first + second).toUpperCase();
}
