import assert from 'node:assert/strict';
import { test } from 'node:test';
import { normalizeWhitespace } from '../src/demo-text.mjs';

test('folds mixed whitespace and trims the result', () => {
  assert.equal(normalizeWhitespace('  hello\tworld\nagain  '), 'hello world again');
});

test('returns an empty string for empty input', () => {
  assert.equal(normalizeWhitespace(''), '');
});

test('preserves Chinese text while normalizing whitespace', () => {
  assert.equal(normalizeWhitespace('\n你好\t世界 ！\n'), '你好 世界 ！');
});

test('rejects non-string input', () => {
  assert.throws(() => normalizeWhitespace(null), TypeError);
});
