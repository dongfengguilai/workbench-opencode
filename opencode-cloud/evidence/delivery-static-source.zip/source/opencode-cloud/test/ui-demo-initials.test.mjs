import { test } from 'node:test';
import { strict as assert } from 'node:assert';
import { initials } from '../src/ui-demo-initials.mjs';

test('Ada Lovelace → AL', () => {
  assert.equal(initials('Ada Lovelace'), 'AL');
});

test('workbench → W', () => {
  assert.equal(initials('workbench'), 'W');
});

test('张 三 → 张三', () => {
  assert.equal(initials('张 三'), '张三');
});

test('empty string → empty string', () => {
  assert.equal(initials(''), '');
});

test('whitespace only → empty string', () => {
  assert.equal(initials('   '), '');
});

test('mixed whitespace splits and trims correctly', () => {
  assert.equal(initials(' \tfoo\nbar\r\xa0baz'), 'FB');
});

test('𐐨 luna → 𐐀L', () => {
  assert.equal(initials('𐐨 luna'), '𐐀L');
});

test('non-string throws TypeError', () => {
  assert.throws(() => initials(42), TypeError);
  assert.throws(() => initials(null), TypeError);
  assert.throws(() => initials(undefined), TypeError);
  assert.throws(() => initials([]), TypeError);
  assert.throws(() => initials({}), TypeError);
});
