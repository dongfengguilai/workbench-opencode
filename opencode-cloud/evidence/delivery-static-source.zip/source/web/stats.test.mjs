import { countCharacters, countWords } from './stats.mjs';

let passed = 0;
let failed = 0;

function assert(condition, msg) {
	if (condition) { passed++; }
	else { failed++; console.error(`  FAIL: ${msg}`); }
}

console.log('=== 文本统计器 测试 ===\n');

// 1. 中文文本
console.log('1) 中文文本');
assert(countCharacters('你好世界') === 4, '中文字符数应为4');
assert(countWords('你好 世界') === 2, '中文词数应为2');

// 2. 非BMP emoji
console.log('2) 非BMP emoji (U+1F600)');
assert(countCharacters('\uD83D\uDE00') === 1, 'emoji码点计数应为1');
assert(countWords('😀🎉') === 1, 'emoji词数应为1');
assert(countCharacters('a😀b') === 3, '混合字符数应为3');

// 3. Tab / 换行
console.log('3) Tab 与换行');
assert(countWords('hello\tworld\nfoo') === 3, 'Tab和换行分隔词数应为3');
assert(countCharacters('a\t\nb') === 4, 'Tab和换行计字符应为4');

// 4. 纯空白
console.log('4) 纯空白');
assert(countWords('   \n\t  ') === 0, '纯空白词数应为0');
assert(countWords('') === 0, '空字符串词数应为0');

// 5. 普通多词
console.log('5) 普通多词');
assert(countWords('Hello world foo bar') === 4, '多词数应为4');
assert(countCharacters('Hello world') === 11, '多词字符数应为11');
assert(countWords('one') === 1, '单字应为1词');

// 6. 混合
console.log('6) 混合中文/emoji/空白');
assert(countCharacters('你好 😀\n世界\t!') === 9, '混合计数应为9');
assert(countWords('你好 😀\n世界\t!') === 4, '混合词数应为4');

console.log(`\n=== 结果: ${passed} 通过, ${failed} 失败 ===`);
if (failed > 0) process.exit(1);
