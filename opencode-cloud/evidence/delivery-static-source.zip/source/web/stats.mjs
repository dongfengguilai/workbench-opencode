export function countCharacters(text) {
	return [...text].length;
}

export function countWords(text) {
	const trimmed = text.trim();
	if (trimmed.length === 0) return 0;
	return trimmed.split(/\s+/).length;
}
